class FormTimeTracker < FormRecord
  attr_accessor :field_time_tracker_category_id, :field_from, :from_time, :field_to, :to_time, :field_note
end