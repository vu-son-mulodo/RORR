class AdminsController < ApplicationController
  before_filter :authenticate_admin!

  layout 'admin'
  def index
    @admins = Admin.get_list.page(params[:page]).per(2)
  end

  def new
    @admin = Admin.new
  end

  def create
    @admin = Admin.new(admin_params)
    if @admin.save
      show_message(I18n.t('others.message.create', :name => @admin.email), CommonHelper::ERROR::SUCCESS)
      redirect_to admin_admins_url
    else
      render action: 'new'
    end
  end
  
  def destroy
    if @admin = check_admin?(params[:id])
      if @admin.delete? 
        show_message(I18n.t('others.message.delete', :name => @admin.email), CommonHelper::ERROR::SUCCESS)
      else
        show_message(I18n.t('others.message.error_server'), CommonHelper::ERROR::DANGER)  
      end
      redirect_to admin_admins_url
    end
  end

    private
    def admin_params
      params.require(:admin).permit(:email, :password, :password_confirmation)
    end
    
    def check_admin?(client_id)
      client = Admin.get_by_id(client_id)
      unless client
        show_message(I18n.t('others.message.not_found.admin'))
        redirect_to admin_admins_url  
      end
      return client
    end
end
