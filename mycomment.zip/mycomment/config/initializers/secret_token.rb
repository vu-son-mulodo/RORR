# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Mycomment::Application.config.secret_token = '7d1166da0c82ba1aabbe83a52a4f3fd4411c5c24cdfb92f151836443ce0d89968eead5887261216effd2569860174d17b211eed15195795b758193cc43e434f5'
