module AccountsHelper
  def list_shop_helper(client_id)
    Shop.find_by_client(client_id).map { |acc| [ acc.name, acc.id ] }
  end
end
