$(document).ready(function(){
  $("#black, #gray").treeview({
    control: "#treecontrol",
    persist: "cookie",
    cookieId: "treeview-black"
  });
});