class Client < ActiveRecord::Base
  attr_accessible :address, :deleted_at, :division1_name, :division2_name, :division3_name, :division4_name, :division5_name, :fax, :industry_id, :name, :name_for_admin, :name_for_user, :note, :postcode, :prefecture_id, :rank1_label, :rank1_point, :rank2_label, :rank2_point, :rank3_label, :rank3_point, :rank4_label, :rank4_point, :rank5_label, :tel, :url
  validates :name, :presence => true
  validates :rank1_label, :presence => true
  validates :rank2_label, :presence => true
  validates :rank3_label, :presence => true
  validates :rank4_label, :presence => true
  validates :rank5_label, :presence => true
  validates :rank1_point, :presence => true
  validates :rank2_point, :presence => true
  validates :rank3_point, :presence => true
  validates :rank4_point, :presence => true
  validates :url, :format => {:allow_nil => true, :allow_blank => true, :with =>/^(http|https):\/\//i,:message => I18n.t('activerecord.errors.messages.invalid')}
  validates :tel, :format => {:allow_nil => true, :allow_blank => true, :with =>/^[0-9\-\+]/i,:message => I18n.t('activerecord.errors.messages.invalid')}
  validates :fax, :format => {:allow_nil => true, :allow_blank => true, :with =>/^[0-9\-\+]/i,:message => I18n.t('activerecord.errors.messages.invalid')}
  validates :prefecture_id, :allow_nil => true, :allow_blank => true, :numericality =>{:greater_than => 0,:less_than_or_equal_to => 49}
  
  def self.get_by_id(id)
    client = Client.find_by_id(id)
    client && client.deleted_at == nil ? client : nil
  end
  def self.get_list
    Client.where(:deleted_at=>nil).order("created_at DESC")
  end
  
  def delete?
    result = self.update_attributes(:deleted_at => Time.now)
    logger.fatal(self.errors.full_messages) unless result
    result  
  end
  
end
