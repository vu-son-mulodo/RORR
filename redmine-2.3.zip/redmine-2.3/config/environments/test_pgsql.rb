instance_eval File.read(File.join(File.dirname(__FILE__), 'test.rb'))
