module ShopsHelper
end
