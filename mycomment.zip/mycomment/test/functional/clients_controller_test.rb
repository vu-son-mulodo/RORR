require 'test_helper'

class ClientsControllerTest < ActionController::TestCase
  setup do
    @client = clients(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:clients)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create client" do
    assert_difference('Client.count') do
      post :create, client: { address: @client.address, deleted_at: @client.deleted_at, division1_name: @client.division1_name, division2_name: @client.division2_name, division3_name: @client.division3_name, division4_name: @client.division4_name, division5_name: @client.division5_name, fax: @client.fax, industry_id: @client.industry_id, name: @client.name, name_for_admin: @client.name_for_admin, name_for_user: @client.name_for_user, note: @client.note, postcode: @client.postcode, prefecture_id: @client.prefecture_id, rank1_label: @client.rank1_label, rank1_point: @client.rank1_point, rank2_label: @client.rank2_label, rank2_point: @client.rank2_point, rank3_label: @client.rank3_label, rank3_point: @client.rank3_point, rank4_label: @client.rank4_label, rank4_point: @client.rank4_point, rank5_label: @client.rank5_label, rank5_point: @client.rank5_point, tel: @client.tel, url: @client.url }
    end

    assert_redirected_to client_path(assigns(:client))
  end

  test "should show client" do
    get :show, id: @client
    assert_response :success
  end

  test "should get edit" do
    get :edit, id: @client
    assert_response :success
  end

  test "should update client" do
    put :update, id: @client, client: { address: @client.address, deleted_at: @client.deleted_at, division1_name: @client.division1_name, division2_name: @client.division2_name, division3_name: @client.division3_name, division4_name: @client.division4_name, division5_name: @client.division5_name, fax: @client.fax, industry_id: @client.industry_id, name: @client.name, name_for_admin: @client.name_for_admin, name_for_user: @client.name_for_user, note: @client.note, postcode: @client.postcode, prefecture_id: @client.prefecture_id, rank1_label: @client.rank1_label, rank1_point: @client.rank1_point, rank2_label: @client.rank2_label, rank2_point: @client.rank2_point, rank3_label: @client.rank3_label, rank3_point: @client.rank3_point, rank4_label: @client.rank4_label, rank4_point: @client.rank4_point, rank5_label: @client.rank5_label, rank5_point: @client.rank5_point, tel: @client.tel, url: @client.url }
    assert_redirected_to client_path(assigns(:client))
  end

  test "should destroy client" do
    assert_difference('Client.count', -1) do
      delete :destroy, id: @client
    end

    assert_redirected_to clients_path
  end
end
