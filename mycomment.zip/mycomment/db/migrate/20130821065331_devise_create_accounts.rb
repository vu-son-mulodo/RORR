class DeviseCreateAccounts < ActiveRecord::Migration
  def change
    create_table(:accounts) do |t|
      ## Database authenticatable
      t.integer :client_id
      t.string  :email,              :null => false, :default => ""
      t.string  :encrypted_password, :null => false, :default => ""
      t.string  :reset_password_token
      t.datetime :remember_created_at
      t.datetime :reset_password_sent_at
      t.integer  :sign_in_count, :default => 0
      t.datetime :current_sign_in_at
      t.datetime :last_sign_in_at
      t.string   :current_sign_in_ip
      t.string   :last_sign_in_ip
      t.string   :password_salt
      t.integer  :failed_attempts
      t.string   :unlock_token
      t.datetime :locked_at
      t.string   :surname,         :null => false
      t.string   :firstname,       :null => false
      t.column   :sex, "ENUM('male', 'female')"
      t.integer  :shop_id
      t.datetime :deleted_at
      t.timestamps
    end

    add_index :accounts, :email,                :unique => true
    add_index :accounts, :reset_password_token, :unique => true
    # add_index :accounts, :confirmation_token,   :unique => true
    # add_index :accounts, :unlock_token,         :unique => true
    # add_index :accounts, :authentication_token, :unique => true
  end
end
