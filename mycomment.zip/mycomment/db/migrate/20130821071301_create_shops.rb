class CreateShops < ActiveRecord::Migration
  def change
    create_table :shops do |t|
      t.references :client, :null => false
      t.string :name, :null => false
      t.string :name_for_admin
      t.string :name_for_user
      t.string :postcode
      t.integer :prefecture_id
      t.string :address
      t.string :building
      t.text :note
      t.string :url
      t.string :tel
      t.string :fax
      t.float :lat
      t.float :lng
      t.datetime :deleted_at

      t.timestamps
    end
    add_index :shops, :client_id
  end
end
