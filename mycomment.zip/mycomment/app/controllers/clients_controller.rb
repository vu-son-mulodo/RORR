class ClientsController < ApplicationController
  before_filter :authenticate_admin!

  layout "admin"
  
  def index
    @clients = Client.get_list.page(params[:page]).per(2)
    respond_to do |format|
      format.html # index.html.erb
      format.json { render json: @clients }
    end
  end

  def show
    @client = check_client?(params[:id])
  end

  def new
    @client = Client.new
  end

  def edit
    @client = check_client?(params[:id])
  end

  def create
    @client = Client.new(client_params)
    if @client.save
      show_message(I18n.t('others.message.create', :name => @client.name), CommonHelper::ERROR::SUCCESS)
      redirect_to admin_client_url(@client)
    else
      render action: "new"  
    end
  end

  def update
    @client = Client.find(params[:id])
    if @client.update_attributes(client_params)
      show_message(I18n.t('others.message.update',:name => @client.name), CommonHelper::ERROR::SUCCESS)
      redirect_to admin_client_url(@client)
    else
      render action: "edit" 
    end
  end

  def destroy
    if @client = check_client?(params[:id])
      if @client.delete? 
        show_message(I18n.t('others.message.delete', :name => @client.name), CommonHelper::ERROR::SUCCESS)
      else
        show_message(I18n.t('others.message.error_server'), CommonHelper::ERROR::DANGER)  
      end
      redirect_to admin_admins_url
    end
  end

  private

    def client_params
      params.require(:client).permit(:address, :deleted_at, :division1_name, :division2_name, :division3_name, :division4_name, :division5_name, :fax, :industry_id, :name, :name_for_admin, :name_for_user, :note, :postcode, :prefecture_id, :rank1_label, :rank1_point, :rank2_label, :rank2_point, :rank3_label, :rank3_point, :rank4_label, :rank4_point, :rank5_label, :rank5_point, :tel, :url)
    end
end
