# encoding: UTF-8
# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended to check this file into your version control system.

ActiveRecord::Schema.define(:version => 20130821071314) do

  create_table "accounts", :force => true do |t|
    t.integer  "client_id"
    t.string   "email",                               :default => "", :null => false
    t.string   "encrypted_password",                  :default => "", :null => false
    t.string   "reset_password_token"
    t.datetime "remember_created_at"
    t.datetime "reset_password_sent_at"
    t.integer  "sign_in_count",                       :default => 0
    t.datetime "current_sign_in_at"
    t.datetime "last_sign_in_at"
    t.string   "current_sign_in_ip"
    t.string   "last_sign_in_ip"
    t.string   "password_salt"
    t.integer  "failed_attempts"
    t.string   "unlock_token"
    t.datetime "locked_at"
    t.string   "surname",                                             :null => false
    t.string   "firstname",                                           :null => false
    t.string   "sex",                    :limit => 6
    t.integer  "shop_id"
    t.datetime "deleted_at"
    t.datetime "created_at",                                          :null => false
    t.datetime "updated_at",                                          :null => false
  end

  add_index "accounts", ["email"], :name => "index_accounts_on_email", :unique => true
  add_index "accounts", ["reset_password_token"], :name => "index_accounts_on_reset_password_token", :unique => true

  create_table "admins", :force => true do |t|
    t.string   "email",                :default => "", :null => false
    t.string   "encrypted_password",   :default => "", :null => false
    t.string   "reset_password_token"
    t.datetime "remember_created_at"
    t.integer  "sign_in_count",        :default => 0
    t.datetime "current_sign_in_at"
    t.datetime "last_sign_in_at"
    t.string   "current_sign_in_ip"
    t.string   "last_sign_in_ip"
    t.string   "password_salt"
    t.integer  "failed_attempts",      :default => 0
    t.string   "unlock_token"
    t.datetime "deleted_at"
    t.datetime "created_at",                           :null => false
    t.datetime "updated_at",                           :null => false
  end

  add_index "admins", ["email"], :name => "index_admins_on_email", :unique => true
  add_index "admins", ["reset_password_token"], :name => "index_admins_on_reset_password_token", :unique => true

  create_table "clients", :force => true do |t|
    t.string   "name",                            :null => false
    t.string   "name_for_admin"
    t.string   "name_for_user"
    t.string   "tel"
    t.string   "fax"
    t.string   "postcode"
    t.integer  "prefecture_id"
    t.string   "address"
    t.string   "building"
    t.integer  "industry_id"
    t.text     "note"
    t.string   "url"
    t.string   "rank1_label",    :default => "A", :null => false
    t.string   "rank2_label",    :default => "B", :null => false
    t.string   "rank3_label",    :default => "C", :null => false
    t.string   "rank4_label",    :default => "D", :null => false
    t.string   "rank5_label",    :default => "E", :null => false
    t.integer  "rank1_point",    :default => 90,  :null => false
    t.integer  "rank2_point",    :default => 80,  :null => false
    t.integer  "rank3_point",    :default => 70,  :null => false
    t.integer  "rank4_point",    :default => 60,  :null => false
    t.string   "division1_name"
    t.string   "division2_name"
    t.string   "division3_name"
    t.string   "division4_name"
    t.string   "division5_name"
    t.datetime "deleted_at"
    t.datetime "created_at",                      :null => false
    t.datetime "updated_at",                      :null => false
  end

  create_table "products", :force => true do |t|
    t.integer  "client_id",      :null => false
    t.string   "name",           :null => false
    t.string   "name_for_admin"
    t.string   "name_for_user"
    t.text     "note"
    t.string   "url"
    t.string   "price",          :null => false
    t.text     "price_note",     :null => false
    t.text     "places"
    t.datetime "deleted_at"
    t.datetime "created_at",     :null => false
    t.datetime "updated_at",     :null => false
  end

  add_index "products", ["client_id"], :name => "index_products_on_client_id"

  create_table "shops", :force => true do |t|
    t.integer  "client_id",      :null => false
    t.string   "name",           :null => false
    t.string   "name_for_admin"
    t.string   "name_for_user"
    t.string   "postcode"
    t.integer  "prefecture_id"
    t.string   "address"
    t.string   "building"
    t.text     "note"
    t.string   "url"
    t.string   "tel"
    t.string   "fax"
    t.float    "lat"
    t.float    "lng"
    t.datetime "deleted_at"
    t.datetime "created_at",     :null => false
    t.datetime "updated_at",     :null => false
  end

  add_index "shops", ["client_id"], :name => "index_shops_on_client_id"

end
