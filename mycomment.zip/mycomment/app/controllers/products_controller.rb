class ProductsController < ApplicationController
  before_filter :authenticate_admin!

  layout 'admin'
  def index
    if @client=check_client?(params[:client_id])
     @products = Product.find_by_client(@client.id).page(params[:page]).per(2)
    end 
  end

  def show
    @product = check_product?(params[:client_id],params[:id]) if @client=check_client?(params[:client_id])
  end

  def new
    @product = Product.new
    @client = Client.find_by_id(params[:client_id])
    check_client?(@client)
  end

  def edit
    @product = check_product?(params[:client_id],params[:id])
  end

  def create
    @product = Product.new(product_params)
    if @client=check_client?(params[:client_id])
      @product.client = @client
      if @product.save
        show_message(I18n.t('others.message.create', :name => @product.name), CommonHelper::ERROR::SUCCESS)
        redirect_to admin_client_product_url(:client_id => @client.id ,:id => @product.id)
      else
        render action: "new" 
      end
    end 
  end

  def update
    if @product = check_product?(params[:client_id],params[:id])
      if @product.update_attributes(product_params)
        show_message(I18n.t('others.message.update',:name => @product.name), CommonHelper::ERROR::SUCCESS)
        redirect_to admin_client_product_url
      else
        render action: "edit" 
      end
    end
  end

  def destroy
    if @product = check_product?(params[:client_id],params[:id])
      @product.delete? ?show_message(I18n.t('others.message.delete', :name => @product.name), CommonHelper::ERROR::SUCCESS) : show_message(I18n.t('others.message.error_server'), CommonHelper::ERROR::DANGER) 
      redirect_to admin_client_products_url
    end
  end

  private

    def product_params
      params.require(:product).permit(:client, :deleted_at, :name, :name_for_admin, :name_for_user, :note, :places, :price, :price_note, :url)
    end
    
    def check_product?(client_id,product_id)
      @product = Product.get_by_id_and_client_id(product_id,client_id)
      unless @product
        show_message(I18n.t('others.message.not_found.product'))
        redirect_to admin_clients_url
      end
      return @product
    end
end
