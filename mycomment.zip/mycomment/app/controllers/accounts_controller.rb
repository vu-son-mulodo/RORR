class AccountsController < ApplicationController
  before_filter :authenticate_admin!

  layout 'admin'

  def index
    if @client=check_client?(params[:client_id])
     @accounts = Account.find_by_client(@client.id).page(params[:page]).per(2)
    end 
  end

  def new
    @account = Account.new
    @client = Client.find_by_id(params[:client_id])
    check_client?(@client)
  end

  def create
    @account = Account.new(account_params)
    if @client=check_client?(params[:client_id])
      @account.client = @client
      if @account.save
        show_message(I18n.t('others.message.create', :name => @account.email), CommonHelper::ERROR::SUCCESS)
        redirect_to admin_client_account_path(:client_id => @client.id ,:id => @account.id)
      else
        render action: "new" 
      end
    end
  end

  def edit
    @account = check_account?(params[:client_id],params[:id])
  end

  def update
    if @account = check_account?(params[:client_id],params[:id])
      if @account.update_attributes(account_params_update)
        show_message(I18n.t('others.message.update',:name => @account.email), CommonHelper::ERROR::SUCCESS)
        redirect_to admin_client_account_path
      else
        render action: "edit" 
      end
    end
  end

  def show
    @account = check_account?(params[:client_id],params[:id])
  end

  def destroy
    if @account = check_account?(params[:client_id],params[:id])
      @account.delete? ? show_message(I18n.t('others.message.delete', :name => @account.email), CommonHelper::ERROR::SUCCESS) : show_message(I18n.t('others.message.error_server'), CommonHelper::ERROR::DANGER) 
      redirect_to admin_client_accounts_url
    end
  end

  private

  def account_params
    params.require(:account).permit(:client_id, :email, :surname,:password, :password_confirmation, :firstname, :sex, :shop_id)
  end
  
  def account_params_update
    params.require(:account).permit(:surname, :firstname, :sex, :shop_id)
  end
  
  def check_account?(client_id,account_id)
    @account = Account.get_by_id_and_client_id(account_id,client_id)
    unless @account
      show_message(I18n.t('others.message.not_found.account'))
      redirect_to admin_clients_url
    end
    return @account
  end
  
end
