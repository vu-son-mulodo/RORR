require File.dirname(__FILE__) + '/../test_helper'

class TermTest < ActiveSupport::TestCase
  fixtures :terms

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
