module ClientsHelper
  def prefectures
    I18n.t('others.prefecture_id').map { |key, value| [ value, key ] }
  end
end
