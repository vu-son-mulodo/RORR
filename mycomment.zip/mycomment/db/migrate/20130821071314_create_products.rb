class CreateProducts < ActiveRecord::Migration
  def change
    create_table :products do |t|
      t.references :client, :null => false
      t.string :name, :null => false
      t.string :name_for_admin
      t.string :name_for_user
      t.text :note
      t.string :url
      t.string :price, :null => false
      t.text :price_note, :null => false
      t.text :places
      t.datetime :deleted_at

      t.timestamps
    end
    add_index :products, :client_id
  end
end
