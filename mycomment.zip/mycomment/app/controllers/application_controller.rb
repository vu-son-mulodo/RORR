class ApplicationController < ActionController::Base
  include CommonHelper
  protect_from_forgery
  
  protected
    def show_message(message, status= CommonHelper::ERROR::DANGER )
      flash[CommonHelper::ERROR::NOTICE],flash[CommonHelper::ERROR::STATUS] = message, status
    end
    
    def check_client?(client_id)
      client = Client.get_by_id(client_id)
      unless client
        show_message(I18n.t('others.message.not_found.client'))
        redirect_to admin_clients_url  
      end
      return client
    end
end
