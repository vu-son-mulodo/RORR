require File.dirname(__FILE__) + '/../test_helper'

class GlossaryStyleTest < ActiveSupport::TestCase
  fixtures :glossary_styles

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
