class CreateClients < ActiveRecord::Migration
  def change
    create_table :clients do |t|
      t.string :name, :null => false
      t.string :name_for_admin
      t.string :name_for_user
      t.string :tel
      t.string :fax
      t.string :postcode
      t.integer :prefecture_id
      t.string :address
      t.string :building
      t.integer :industry_id
      t.text :note
      t.string :url
      t.string :rank1_label, :default => 'A', :null => false
      t.string :rank2_label, :default => 'B', :null => false
      t.string :rank3_label, :default => 'C', :null => false
      t.string :rank4_label, :default => 'D', :null => false
      t.string :rank5_label, :default => 'E', :null => false
      t.integer :rank1_point, :default => 90, :null => false
      t.integer :rank2_point, :default => 80, :null => false
      t.integer :rank3_point, :default => 70, :null => false
      t.integer :rank4_point, :default => 60, :null => false
      t.string :division1_name
      t.string :division2_name
      t.string :division3_name
      t.string :division4_name
      t.string :division5_name
      t.datetime :deleted_at

      t.timestamps
    end
  end
end
