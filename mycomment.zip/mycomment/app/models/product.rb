class Product < ActiveRecord::Base
  belongs_to :client
  attr_accessible :deleted_at, :name, :name_for_admin, :name_for_user, :note, :places, :price, :price_note, :url
  
  validates :name, :presence => true
  validates :url, :format => {:allow_nil => true, :allow_blank => true, :with =>/^(http|https):\/\//i,:message => I18n.t('activerecord.errors.messages.invalid')}
  
  def self.get_list
    Product.where(:deleted_at=>nil).order("created_at DESC")
  end
  def self.find_by_client(client_id)
    Product.where(:client_id => client_id,:deleted_at=>nil).order("created_at DESC")
  end
  def self.get_by_id(client_id,id)
    product = Product.find_by_id_and_client_id_and_deleted_at(id,client_id,nil)
    product ? product : nil
  end
  
  def delete?
    result = self.update_attributes(:deleted_at => Time.now)
    logger.fatal(self.errors.full_messages) unless result
    result  
  end
  
end
