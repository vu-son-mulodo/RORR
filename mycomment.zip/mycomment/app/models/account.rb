class Account < ActiveRecord::Base
  before_save :object_reference
  belongs_to :client
  belongs_to :shop
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :trackable, :validatable
         
  attr_accessible :email, :password, :password_confirmation, :remember_me, :client_id, :email, :encrypted_password,:sex, :surname,:deleted_at, :firstname, :shop_id
  
  validates :client, :presence => true
  validates :surname, :presence => true
  validates :firstname, :presence => true
  validates :sex, :presence => true
  
  def self.get_list
    Account.where(:deleted_at=>nil).order("created_at DESC")
  end
  def self.find_by_client(client_id)
    Account.where(:client_id => client_id,:deleted_at=>nil).order("created_at DESC")
  end
  def self.get_by_id_and_client_id(id,client_id)
    account = Account.find_by_id_and_client_id_and_deleted_at(id,client_id,nil)
    account ? account : nil
  end
  
  def delete?
    result = self.update_attributes(:deleted_at => Time.now)
    logger.fatal(self.errors.full_messages) unless result
    result  
  end
  
  def object_reference
    self.shop = Shop.get_by_id(self.shop_id)
  end
end
