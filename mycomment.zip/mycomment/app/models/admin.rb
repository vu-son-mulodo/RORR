class Admin < ActiveRecord::Base
  # Include default devise modules. Others available are:
  # :token_authenticatable, :confirmable,
  # :lockable, :timeoutable and :omniauthable
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :trackable, :validatable
  # attr_accessible :title, :body
  attr_accessible :email, :password, :password_confirmation, :remember_me, :deleted_at
  
  def self.get_list
    Admin.where(:deleted_at=>nil).order("created_at DESC")
  end
  def self.get_by_id(id)
    admin = Admin.find_by_id_and_deleted_at(id,nil)
    admin ? admin : nil
  end
  def delete?
    result = self.update_attributes(:deleted_at => Time.now)
    logger.fatal(self.errors.full_messages) unless result
    result  
  end
  
end
