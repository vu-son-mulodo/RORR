module CommonHelper
  class ERROR
    DANGER = 'danger'
    WARNING = 'warning'
    SUCCESS = 'success'
    INFO = 'info'
    NOTICE = 'notice'
    STATUS = 'status'
  end   
end
