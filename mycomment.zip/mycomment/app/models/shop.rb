class Shop < ActiveRecord::Base
  belongs_to :client
  attr_accessible :address, :building, :deleted_at, :fax, :lat, :lng, :name, :name_for_admin, :name_for_user, :note, :postcode, :prefecture_id, :tel, :url

  validates :name, :presence => true
  validates :url, :format => {:allow_nil => true, :allow_blank => true, :with =>/^(http|https):\/\//i,:message => I18n.t('activerecord.errors.messages.invalid')}
  validates :tel, :format => {:allow_nil => true, :allow_blank => true, :with =>/^[0-9\-\+]/i,:message => I18n.t('activerecord.errors.messages.invalid')}
  validates :fax, :format => {:allow_nil => true, :allow_blank => true, :with =>/^[0-9\-\+]/i,:message => I18n.t('activerecord.errors.messages.invalid')}
  validates :prefecture_id, :allow_nil => true, :allow_blank => true, :numericality =>{:greater_than => 0,:less_than_or_equal_to => 49}
 
  def self.find_by_client(client_id)
    Shop.where(:client_id => client_id,:deleted_at=>nil).order("created_at DESC")
  end
  
  def self.get_by_id(client_id,id)
    shop = Shop.find_by_id_and_client_id_and_deleted_at(id,client_id,nil)
    shop ? shop : nil
  end
  
  def self.get_list
    Shop.where(:deleted_at=>nil).order("created_at DESC")
  end
  
  def delete?
    result = self.update_attributes(:deleted_at => Time.now)
    logger.fatal(self.errors.full_messages) unless result
    result  
  end

end
