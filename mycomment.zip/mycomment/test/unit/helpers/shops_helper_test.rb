require 'test_helper'

class ShopsHelperTest < ActionView::TestCase
end
