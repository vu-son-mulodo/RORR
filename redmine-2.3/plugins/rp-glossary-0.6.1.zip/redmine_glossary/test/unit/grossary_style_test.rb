require File.dirname(__FILE__) + '/../test_helper'

class GrossaryStyleTest < ActiveSupport::TestCase
  fixtures :grossary_styles

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
