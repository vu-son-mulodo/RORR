class AccountsController < ApplicationController
  before_filter :authenticate_admin!

  layout 'admin'

  def index
    @accounts = Account.all

    respond_to do |format|
      format.html # index.html.erb
      format.json { render json: @accounts }
    end
  end

  def new
    @account = Account.new

    respond_to do |format|
      format.html { render layout: 'admin_no_filter'}
      format.json { render json: @account }
    end
  end

  def create
    @account = Account.new(account_params)

    respond_to do |format|
      if @account.save
        format.html { redirect_to @account, notice: 'Account was successfully created.' }
        format.json { render json: @account, status: :created, location: @account }
      else
        format.html { render action: "new", layout: 'admin_no_filter' }
        format.json { render json: @account.errors, status: :unprocessable_entity }
      end
    end
  end

  def edit
    @account = Account.find(params[:id])
      respond_to do |format|
      format.html { render layout: 'admin_no_filter'}
    end
  end

  def update
    @account = Account.find(params[:id])
    respond_to do |format|
      format.html { render layout: 'admin_no_filter'}
    end
    if @account.update_attributes(params[:surname])
      redirect_to :action => 'show', :id => @account
    else
      render :action => 'index'
    end
  end

  def show
    @account = Account.find(params[:id])
    respond_to do |format|
      format.html { render layout: 'admin_no_filter'}
    end
  end

  # DELETE /admins/1
  # DELETE /admins/1.json
  def destroy
    @account = Account.find(params[:id])
    @account.destroy

    respond_to do |format|
      format.html { redirect_to accounts_url }
      format.json { head :no_content }
    end
  end

  private

  # Use this method to whitelist the permissible parameters. Example:
  # params.require(:person).permit(:name, :age)
  # Also, you can specialize this method with per-user checking of permissible attributes.
  def account_params
    #params.require(:account).permit(:client_id, :email, :surname, :firstname, :encrypted_password, :reset_password_token, :remember_created_at, :reset_password_sent_at, :sign_in_count, :current_sign_in_at, :last_sign_in_at, :current_sign_in_ip, :last_sign_in_ip, :password_salt, :failed_attempts, :unlock_token, :locked_at, :surname, :firstname, :sex, :shop_id, :deleted_at)
    params.require(:account).permit(:client_id, :email, :surname, :firstname,:password, :password_confirmation, :surname, :firstname, :sex, :shop_id)
  end
end
