class ShopsController < ApplicationController
  before_filter :authenticate_admin!

  layout 'admin'
  def index
    if @client=check_client?(params[:client_id])
     @shops = Shop.find_by_client(@client.id).page(params[:page]).per(2)
    end 
  end

  def show
    if @client=check_client?(params[:client_id])
      @shop = check_shop?(@client.id,params[:id])
    end
  end

  def new
    @shop = Shop.new
    @client = Client.find_by_id(params[:client_id])
    check_client?(@client)
  end

  def edit
    if @client=check_client?(params[:client_id])
      @shop = check_shop?(@client.id,params[:id])
    end
  end

  def create
    @shop = Shop.new(shop_params)
    if @client=check_client?(params[:client_id])
      @shop.client = @client
      if @shop.save
        show_message(I18n.t('others.message.create', :name => @shop.name), CommonHelper::ERROR::SUCCESS)
        redirect_to admin_client_shop_path(:client_id => @client.id ,:id => @shop.id)
      else
        render  action: "new"
      end
    end  
  end

  def update
    if @client=check_client?(params[:client_id])
      if @shop = check_shop?(@client.id,params[:id])
        if @shop.update_attributes(shop_params)
          show_message(I18n.t('others.message.update',:name => @shop.name), CommonHelper::ERROR::SUCCESS)
          redirect_to admin_client_shop_path(:client_id => @client.id,:id => @shop.id)
        else
          render action: "edit" 
        end
      end
    end
  end

  def destroy
    if @client=check_client?(params[:client_id])
      if @shop = check_shop?(@client.id,params[:id])
        if @shop.delete? 
          show_message(I18n.t('others.message.delete', :name => @shop.name), CommonHelper::ERROR::SUCCESS)
        else
          show_message(I18n.t('others.message.error_server'), CommonHelper::ERROR::DANGER)  
        end
        redirect_to admin_client_shops_url(:client_id => @client.id)
      end
    end
  end

  private

    def shop_params
      params.require(:shop).permit(:address, :building, :fax, :lat, :lng, :name, :name_for_admin, :name_for_user, :note, :postcode, :prefecture_id, :tel, :url)
    end
    
    def check_shop?(client_id,shop_id)
      @shop = Shop.get_by_id(client_id,shop_id)
      unless @shop
        show_message(I18n.t('others.message.not_found.shop'))
        redirect_to admin_clients_url
      end
      return @shop
    end 
end
