class ListTimeTracker < FormRecord
  attr_accessor :date_from,:data
end